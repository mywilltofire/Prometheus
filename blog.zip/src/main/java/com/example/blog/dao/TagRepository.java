package com.example.blog.dao;

import com.example.blog.po.Tag;
import org.springframework.boot.autoconfigure.data.web.SpringDataWebProperties;

import java.util.List;

public interface TagRepository extends JpaRepository<Tag,Long>{

    Tag findByName(String name);

    @Query("select t from Tag t")
    List<Tag> findTop(SpringDataWebProperties.Pageable pageable);
}
