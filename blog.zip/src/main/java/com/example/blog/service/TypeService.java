package com.example.blog.service;

import com.example.blog.po.Type;
import sun.jvm.hotspot.debugger.Page;

import java.awt.print.Pageable;
import java.util.List;

public interface TypeService {

    //新增type
    Type saveType(Type type);

    //查询type
    Type getType(Long id);

    //
    Type getTypeByName(String name);

    //得到type列表
    Page<Type> listType(Pageable pageable);

    List<Type> listType();

    List<Type> listTypeTop(Integer size);

    //修改type
    Type updateType(Long id,Type type);

    //删除type
    void deleteType(Long id);
}
