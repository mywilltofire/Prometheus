package com.example.blog.web;

import com.example.blog.NotFoundExpection;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class indexController {
    @GetMapping("/")
    public String index(){
        //int i = 9/0;//测试404
        /*//测试NotFoundExpection
        String blog = null;
        if (blog == null){
            throw new NotFoundExpection("博客不存在");
        }*/
        //测试aspect
        System.out.println("index");
        return "index";
    }

    @GetMapping("/blog")
    public String blog(){
        return "blog";
    }
}
